#ifndef _DISCOVERY_H_
#define _DISCOVERY_H_

#include "libraries.h"

#define MAX_FILES_DIRS 1024

void discovery(int no_words, str args[]);

#endif
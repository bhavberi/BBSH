#ifndef _INPUT_H_
#define _INPUT_H_

#include "libraries.h"

#define INPUTLENGTH_MAX 2048

str get_raw_input();
void input();

#endif